<template>
  <div class="allBox">
    <mycard/>
  </div>
</template>

<script>
import mycard from '@/components/card'
export default {
  name: "other",
  components:{
    mycard
  }
};
</script>

<style scoped>

</style>
