<template>
  <div class="allBox">
    <itemCard/>
    <itemCard/>
    <itemCard/>
  </div>
</template>

<script>
import itemCard from '@/components/itemCard'
export default {
  name: "findTeam",
  components:{
    itemCard
  }
};
</script>

<style scoped>

</style>
