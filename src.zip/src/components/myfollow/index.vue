<template>
  <div class="allBox">
    <mycard/>
  </div>
</template>

<script>
import mycard from '@/components/card'
export default {
  name: "myfollow",
  components:{
    mycard
  }
};
</script>

<style scoped>

</style>
