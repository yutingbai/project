<template>
    <div><mycard/></div>
</template>
<script>
import mycard from '@/components/card'
export default {
    name:'myStars'
}
</script>
<style>

</style>