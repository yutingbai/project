<template>
  <div class="allBox">
    <itemCard/>
    <itemCard/>
   
  </div>
</template>

<script>
import itemCard from '@/components/itemCard'
export default {
  name: "findItem",
  components:{
    itemCard
  }
};
</script>

<style scoped>

</style>
